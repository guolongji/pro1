<?php

namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;

class DemoController extends Controller{


	public $enableCsrfValidation = false;

	public function actionIndex(){
		return $this->render("index");
	}	

	public function actionDoadd(){

		
		var_dump($_FILES);

	}



	//评论
	public function actionComment(){

		$sql = "select * from article limit 1";
		$data = Yii::$app->db->createCommand($sql)->queryone();

		

		return $this->render("comment",["data"=>$data]);
	}
}